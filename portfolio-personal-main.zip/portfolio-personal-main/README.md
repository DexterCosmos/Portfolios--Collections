# Responsive Portfolio Website
## [Watch it on youtube](https://youtu.be/jRMCheGk11E)
### Responsive Portfolio Website

- Responsive Portfolio Website Using HTML CSS & JavaScript
- Contains animations with gsap.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
